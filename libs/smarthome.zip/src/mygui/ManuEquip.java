package mygui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;

import UIComponent.DynamicText;
import UIComponent.InputArea;
import UIComponent.InputText;
import UIComponent.MenuBar;
import UIComponent.MyLabelComponent;
import UIComponent.MyReminder;
import UIComponent.Password;
import UIComponent.ReminderTool;
import UIComponent.TableList;
import UIComponent.TableTool;
import UIComponent.TextButton;
import UIComponent.UIStyle;
import manufacturer.query;

public class ManuEquip
{

    public int manuid;

    public ManuEquip()
    {
        this.manuid = 0;
    }

    public ManuEquip(int manuid)
    {
        this.manuid = manuid;
    }


    public void run()
    {
        new UIStyle();
        JFrame jf = new JFrame();
        jf.setBounds((int) ((UIStyle.ScreenWidth - UIStyle.width) / 2), (int) (UIStyle.ScreenHeight - UIStyle.height) / 2, (int) UIStyle.width, (int) UIStyle.height);
        JPanel testPanel = new JPanel();
        testPanel.setLayout(null);
        //jf.add(testPanel);

        Font NORMAL_FONT = new Font("Arial", Font.PLAIN, 18);
        Font BIG_FONT = new Font("Arial", Font.PLAIN, 34);

        ReminderTool tool = new ReminderTool();
        testPanel.add(tool);

        TextButton quit = new TextButton(UIStyle.width - 30, 30, Color.decode("#58606A"), Color.black, "QUIT", 30, 30, "tiny", true);
        tool.add(quit);

        TextButton mini = new TextButton(UIStyle.width - 70, 30, Color.decode("#58606A"), Color.black, "MINI", 30, 30, "tiny", true);
        tool.add(mini);

        TextButton back = new TextButton(30, 30, Color.decode("#58606A"), Color.black, "BACK", 30, 30, "tiny", true);
        tool.add(back);

        DynamicText top = new DynamicText(UIStyle.width / 2 / 2 + 50, UIStyle.height / 2 - 250, "mid", Color.decode("#58606A"), Color.BLACK, "HardWare Management", 400, 100, BIG_FONT);
        testPanel.add(top);

        TextButton a = new TextButton(UIStyle.width / 2 - 250, UIStyle.height / 2 - 130, Color.decode("#ACC7F1"), Color.black, "Search Information", 170, 50, "mid", true);
        TextButton b = new TextButton(UIStyle.width / 2 + 250, UIStyle.height / 2 - 130, Color.decode("#ACC7F1"), Color.black, "Modify Information", 170, 50, "mid", true);

        testPanel.add(a);
        testPanel.add(b);


        String[] attribute = {"Equipment ID", "Equipment Name", "Equipment introduction", "Equipment type", "Manufacturer id", "Family id"};
        String[][] value = query.queryequipment(manuid);

        TableList table = new TableList(attribute, value, Color.BLACK, Color.WHITE, Color.decode("#F0F8FF"), UIStyle.width / 2 - 485, UIStyle.height / 2 / 2, UIStyle.width - 10, UIStyle.height / 2);
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setPreferredSize(new Dimension(0, 350));

        scrollPane.setViewportView(table);
        jf.getContentPane().setLayout(new BorderLayout());
        jf.getContentPane().add(scrollPane, BorderLayout.SOUTH);
        jf.getContentPane().add(testPanel);
        quit.addMouseListener(new MouseListener()
        {

            @Override
            public void mouseClicked(MouseEvent e)
            {
                // TODO Auto-generated method stub

            }

            @Override
            public void mousePressed(MouseEvent e)
            {
                // TODO Auto-generated method stub

            }

            @Override
            public void mouseReleased(MouseEvent e)
            {
                // TODO Auto-generated method stub
                System.exit(0);
            }

            @Override
            public void mouseEntered(MouseEvent e)
            {
                // TODO Auto-generated method stub

            }

            @Override
            public void mouseExited(MouseEvent e)
            {
                // TODO Auto-generated method stub

            }


        });

        mini.addMouseListener(new MouseListener()
        {

            @Override
            public void mouseClicked(MouseEvent e)
            {
                // TODO Auto-generated method stub

            }

            @Override
            public void mousePressed(MouseEvent e)
            {
                // TODO Auto-generated method stub

            }

            @Override
            public void mouseReleased(MouseEvent e)
            {
                // TODO Auto-generated method stub
                jf.setExtendedState(JFrame.ICONIFIED);
            }

            @Override
            public void mouseEntered(MouseEvent e)
            {
                // TODO Auto-generated method stub

            }

            @Override
            public void mouseExited(MouseEvent e)
            {
                // TODO Auto-generated method stub

            }


        });

        back.addMouseListener(new MouseListener()
        {

            @Override
            public void mouseClicked(MouseEvent e)
            {
                // TODO Auto-generated method stub

            }

            @Override
            public void mousePressed(MouseEvent e)
            {
                // TODO Auto-generated method stub

            }

            @Override
            public void mouseReleased(MouseEvent e)
            {
                // TODO Auto-generated method stub
                ManuOperation l = new ManuOperation(manuid);
                l.run();
                jf.setVisible(false);
            }

            @Override
            public void mouseEntered(MouseEvent e)
            {
                // TODO Auto-generated method stub

            }

            @Override
            public void mouseExited(MouseEvent e)
            {
                // TODO Auto-generated method stub

            }


        });

        a.addMouseListener(new MouseAdapter()
        {

            @Override
            public void mouseClicked(MouseEvent e)
            {
                // TODO Auto-generated method stub
                ManuFind l = new ManuFind(manuid);
                l.run();
                jf.setVisible(false);
            }


        });

        b.addMouseListener(new MouseAdapter()
        {

            @Override
            public void mouseClicked(MouseEvent e)
            {
                // TODO Auto-generated method stub
                ManuMod l = new ManuMod(manuid);
                l.run();
                jf.setVisible(false);
            }


        });


        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jf.setUndecorated(true);
        jf.setVisible(true);


    }

    public static void main(String[] args)
    {
        ManuEquip l = new ManuEquip();
        l.run();
    }


}

